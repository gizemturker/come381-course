# Week 05 — Ödev 1 ve Ödev 2

## Senaryo
Bir atölye, müşterilerin farklı eğitmenler tarafından verilen atölyelere kayıt yaptırdığı bir sistem kullanır. Her atölyenin kapasitesi ve başlangıç/bitiş tarihi vardır. Bir müşteri birçok atölyeye, bir atölye de birçok müşteriye sahip olabilir. `registration` ara tablosu bu M:N ilişkiyi çözer. Eğitmenler birden fazla atölye verebilir.

## Tasarım kararı
`registration` için ayrı bir birincil anahtar yerine `(customer_id, workshop_id)` bileşik anahtarı seçildi; böylece aynı müşteri aynı atölyeye iki kez kayıt olamaz. `workshop` tablosundaki tarih ve kapasite kuralları CHECK ile korunur.

## Ödev 1
- [ER diyagramı](docs/er.md)
- [Çalışan PostgreSQL şeması](sql/schema.sql) — 4 tablo, M:N ilişki, PK ve FK

## Ödev 2
- [Constraint eklemeleri](sql/constraints.sql)
- [İhlal testleri](sql/violations.sql) ve [örnek çıktı açıklamaları](sql/violations_output.txt)
- [Silme politikaları](sql/on_delete.md)
- [İlişkisel cebir](docs/algebra.md) ve [SQL karşılıkları](sql/algebra.sql)
- [Örnek veriler](sql/seed.sql)

## Çalıştırma sırası
```bash
createdb come381_test
psql -d come381_test -v ON_ERROR_STOP=1 -f sql/schema.sql
psql -d come381_test -v ON_ERROR_STOP=1 -f sql/constraints.sql
psql -d come381_test -v ON_ERROR_STOP=1 -f sql/seed.sql
psql -d come381_test -f sql/violations.sql
psql -d come381_test -f sql/algebra.sql
```
İhlal dosyasında **beklenen hatalar** bulunur; bu yüzden `ON_ERROR_STOP` kullanılmaz. Testleri tekrar çalıştırmadan önce veritabanını yeniden oluşturun.

**Not:** Bu dosyalar PostgreSQL sunucusunda çalıştırılarak doğrulanmadı; `violations_output.txt` gerçek terminal kaydı değil, beklenen SQLSTATE kodlarıdır.
