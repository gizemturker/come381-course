# Ödev 1 — ER Diyagramı

```mermaid
erDiagram
    INSTRUCTOR ||--o{ WORKSHOP : teaches
    CUSTOMER ||--o{ REGISTRATION : registers
    WORKSHOP ||--o{ REGISTRATION : contains
    INSTRUCTOR {
      int instructor_id PK
      varchar full_name
      varchar email UK
    }
    CUSTOMER {
      int customer_id PK
      varchar full_name
      varchar email UK
    }
    WORKSHOP {
      int workshop_id PK
      int instructor_id FK
      varchar title
      int capacity
      date start_date
      date end_date
    }
    REGISTRATION {
      int customer_id PK,FK
      int workshop_id PK,FK
      date registered_on
    }
```

**Kardinaliteler:** Eğitmen 1:N Atölye; Müşteri 1:N Kayıt; Atölye 1:N Kayıt. Böylece Müşteri–Atölye ilişkisi M:N olur.
