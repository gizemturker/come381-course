# Ödev 2 — İlişkisel Cebir

Kullanılan semboller: σ seçim, π projeksiyon, ⋈ birleşim, ∪ birleşim kümesi, ∩ kesişim, − fark, ÷ bölme.

1. **Seçim ve projeksiyon:** Kapasitesi 10'dan büyük atölyelerin adları: π_title(σ_capacity>10(WORKSHOP))
2. **Join:** Kayıt yaptıran müşteriler ve atölyeleri: π_full_name,title(CUSTOMER ⋈ REGISTRATION ⋈ WORKSHOP) (eşleştirmeler ilgili ID sütunları üzerinden).
3. **Union:** Ceramics veya Painting'e kayıtlı müşteri kimlikleri: π_customer_id(σ_workshop_id=1(REGISTRATION)) ∪ π_customer_id(σ_workshop_id=2(REGISTRATION))
4. **Intersection:** Hem Ceramics hem Painting'e kayıtlı müşteri kimlikleri: π_customer_id(σ_workshop_id=1(REGISTRATION)) ∩ π_customer_id(σ_workshop_id=2(REGISTRATION))
5. **Difference:** Ceramics'e kayıtlı olup Painting'e kayıtlı olmayan müşteriler: π_customer_id(σ_workshop_id=1(REGISTRATION)) − π_customer_id(σ_workshop_id=2(REGISTRATION))
6. **Division:** Tüm atölyelere kayıtlı müşteriler: π_customer_id,workshop_id(REGISTRATION) ÷ π_workshop_id(WORKSHOP)

SQL karşılıkları `sql/algebra.sql` dosyasındadır. Atölye ID 1 ve 2, `seed.sql` içindeki Ceramics ve Painting kayıtlarıdır.
